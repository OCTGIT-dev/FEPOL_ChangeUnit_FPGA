### PROJECT : STRAFFIC FEPOL  
###### 납품처 : STRAFFIC
###### 구분 : FPGA
###### Compiler: Compiler: ISE 14.7 / Target IC: CPLD (XC95288XL-10TQG144I)
---
### 주요사양
---    
* Upload 규칙
  - Commit시 변경내역 항시 기재
  - Share Branch에 Upload
  - Master Branch는 관리자만이 수정 및 관리
  - Master Branch에 Merge 진행시 Pull Request를 요청하여 관리자를 통한 Merge 
---    
### Revision History
  - Ver 1.0.0 : Init Code
